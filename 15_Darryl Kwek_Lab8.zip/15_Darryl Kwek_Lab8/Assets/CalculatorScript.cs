﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{

    public InputField InputAmount;
    public InputField InputConvertAmount;
    public Button Convert;
    public Button Clear;
    public Toggle USDollars;
    public Toggle JapaneseYen;
    public Text Debugging;

    private float USD = 0.74f;
    private float Yen = 82.78f;
    private float Total;

    // Start is called before the first frame update
    void Start()
    {
        USDollars.isOn = false;
        JapaneseYen.isOn = false;
    }

    // Update is called once per frame
    void Update()
    {        

        

    }
     
    public void Conversion()
    {
        float amount = float.Parse(InputAmount.text);


        if (USDollars.isOn == true && JapaneseYen.isOn == false)
        {
            Total = amount * USD;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }

        else if (JapaneseYen.isOn == true && USDollars.isOn == false)
        {

            Total = amount * Yen;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }


        else if (JapaneseYen.isOn == false && USDollars.isOn == false)
        {
            Debugging.text = "Please select one of the currencies.";
        }
    }

    public void ClearButton()
    {
        InputConvertAmount.text = "";
        Debugging.text = "";
        JapaneseYen.isOn = false;
        USDollars.isOn = false;
        InputAmount.text = "";
    }

}
