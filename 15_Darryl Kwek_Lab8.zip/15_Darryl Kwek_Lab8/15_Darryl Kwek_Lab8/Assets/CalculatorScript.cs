﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{

    public InputField InputAmount;
    public InputField InputConvertAmount;
    public Button Convert;
    public Button Clear;
    public Toggle USDollars;
    public Toggle JapaneseYen;
    public Toggle Riggit;
    public Toggle Euro;
    public Toggle Korea;
    public Toggle Thai;
    public Text Debugging;

    private float USD = 0.74f;
    private float Yen = 82.78f;
    private float RM = 3.08f;
    private float EUR = 0.63f;
    private float KRW = 881.54f;
    private float TWD = 20.73f;
    private float Total;

    // Start is called before the first frame update
    void Start()
    {
        USDollars.isOn = false;
        JapaneseYen.isOn = false;
        Riggit.isOn = false;
        Euro.isOn = false;
        Korea.isOn = false;
        Thai.isOn = false;

    }
    public void Conversion()
    {
        float amount = float.Parse(InputAmount.text);


        if (USDollars.isOn == true && JapaneseYen.isOn == false)
        {
            Total = amount * USD;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }

        else if (JapaneseYen.isOn == true && USDollars.isOn == false)
        {

            Total = amount * Yen;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }

        else if(Riggit.isOn == true)
        {
                
             Total = amount * RM;
             InputConvertAmount.text = "$" + (Total);
             Debugging.text = "";          
        }
        else if(Euro.isOn == true)
        {
            Total = amount * EUR;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }
        else if(Korea.isOn == true)
        {
            Total = amount * KRW;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }
        else if(Thai.isOn == true)
        {
            Total = amount * TWD;
            InputConvertAmount.text = "$" + (Total);
            Debugging.text = "";
        }
        else if (JapaneseYen.isOn == false && USDollars.isOn == false)
        {
            Debugging.text = "Please select one of the currencies.";
        }











    }

    public void ClearButton()
    {
        InputConvertAmount.text = "";
        Debugging.text = "";
        JapaneseYen.isOn = false;
        USDollars.isOn = false;
        InputAmount.text = "";
    }

}
